public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean result = new Pythagorean();
        double output = result.calculateHypotenuse(1,2);
        System.out.println(output);
    }
}