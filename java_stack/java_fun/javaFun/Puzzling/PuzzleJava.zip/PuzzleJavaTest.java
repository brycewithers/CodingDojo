import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class PuzzleJavaTest {

    public static void main(String[] args) {
        PuzzleJava test = new PuzzleJava();

        test.printSumAndReturnNew();
        test.shuffleNamesAndReturn();
        test.alphabetShuffle();
        test.randomArr();
        test.randomArrSorted();
        test.randomString();
        test.randomStringsArr();
    }
}