public class FizzBuzzTest {
    public static void main(String[] args) {
        FizzBuzz test = new FizzBuzz();
        test.fizzBuzz(5);
        test.fizzBuzz(15);
        test.fizzBuzz(2);
        test.fizzBuzz(10);
    }
}