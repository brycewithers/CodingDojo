import React from 'react';
import './App.css';

import { Router, Redirect } from '@reach/router';

import NewProduct from "./views/NewProduct";
import Products from "./views/Products";
import Product from "./views/Product";
import EditProduct from "./views/EditProduct";

function App() {
  return (
    <div className="App">
      <Router>
        <Redirect from="/" to="/products" noThrow="true" />
        <NewProduct path="/products/new" />
        <Products path='/products' />
        <Product path='/products/:id' />
        <EditProduct path='/products/:id/edit' />
      </Router>
    </div>
  );
}

export default App;
