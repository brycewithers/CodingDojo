import React, { useState } from "react";

import axios from "axios";

const NewProduct = (props) => {
    const [title, setTitle] = useState('');
    const [price, setPrice] = useState('');
    const [description, setDescription] = useState('');
    const [errors, setErrors] = useState('');

    function handleSubmit(event) {
        event.preventDefault();

        const newProduct = {
            title,
            price,
            description,
        };

        axios
            .post('http://localhost:8000/api/products/new', newProduct)
            .then((res) => {
                console.log(res.data);
                props.setProducts([...props.products, res.data]);

                setTitle('');
                setPrice('');
                setDescription('');
            })
            .catch((err) => {
                console.log(err.response);
                setErrors(err.response.data.errors);
            });
        // axios
        //     .post('http://localhost:8000/api/products/new', newProduct)
        //     .then((res) => {
        //         navigate('/products')
        //     })
        //     .catch((err) => {
        //         console.log(err);
        //         setErrors(err.response.data.errors);
        //     });
    }

    return (
        <div>
            <h2>Product Manager</h2>
            
            <form 
                onSubmit= {(event) => {
                    handleSubmit(event);
                }}
                >
                <div>
                    <label>Title: </label>
                    <input 
                        value={title}
                        type='text'
                        onChange={(event) => {
                            setTitle(event.target.value);
                        }}
                        />
                    {errors?.title && (
                        <span style={{ color: "red" }}>{errors?.title?.message}</span>
                        )}
                </div>

                <div>
                    <label>Price: </label>
                    <input
                        value={price} 
                        type='number'
                        onChange={(event) => {
                            setPrice(event.target.value);
                        }}
                        />
                    {errors?.price && (
                        <span style={{ color: "red" }}>{errors?.price?.message}</span>
                        )}
                </div>

                <div>
                    <label>Description: </label>
                    <input 
                        value={description}
                        type='text'
                        onChange={(event) => {
                            setDescription(event.target.value);
                        }}
                        />
                    {errors?.description && (
                        <span style={{ color: "red" }}>{errors?.description?.message}</span>
                        )}
                </div>

                <button>Create</button>
            </form>
        </div>
    );
};

export default NewProduct;