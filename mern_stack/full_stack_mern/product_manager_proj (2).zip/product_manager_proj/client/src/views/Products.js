import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "@reach/router";

import NewProductForm from '../components/NewProductForm';

const Products = (props) => {
  const [products, setProducts] = useState(null);

  useEffect(() => {
    getAllProducts();
  }, [props.id]);

  function getAllProducts() {
    axios
      .get('http://localhost:8000/api/products')
      .then((res) => {
        console.log(res.data);
        setProducts(res.data)
      })
      .catch((err) => {
        console.log(err);
      });
  }

  if (products === null) {
    return 'loading...'
  }

  return (
    <div>
      <NewProductForm products={products} setProducts={setProducts} />
      <hr/>
      <h1>All Products:</h1>
      {products.map((product) => {
        return <div key={product._id}>
          <h3>
            <Link to={`/products/${product._id}`}>{product.title}</Link>
          </h3>
          {/* <p>${product.price}</p>
          <p>{product.description}</p>
          <hr/> */}
        </div>
      })}
    </div>
  );
};

export default Products;
