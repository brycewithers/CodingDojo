import React, { useEffect, useState } from "react";
import { navigate, Link } from "@reach/router";

import axios from "axios";

const EditProduct = (props) => {
    const [title, setTitle] = useState('');
    const [price, setPrice] = useState('');
    const [description, setDescription] = useState('');
    const [errors, setErrors] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:8000/api/products/" + props.id)
      .then((res) => {
        console.log("edit product .then!!!");
        setTitle(res.data.title);
        setPrice(res.data.price);
        setDescription(res.data.description);
      })
      .catch((err) => {
        console.error(err);
      });
  }, []);

  function handleSubmit(event) {
    event.preventDefault();

    const editedProduct = {
        title,
        price,
        description,
    };

    console.log(editedProduct);

    axios
      .put("http://localhost:8000/api/products/update/" + props.id, editedProduct)
      .then((res) => {
        console.log(res);
        navigate("/products");
      })
      .catch((err) => {
        setErrors(err.response.data.errors);
      });
  }

  function handleDelete() {
    axios
      .delete("http://localhost:8000/api/products/delete/" + props.id)
      .then((res) => {
        navigate("/products");
      })
      .catch((err) => {
        console.log(err.response);
      });
  }

  return (
    <div>
      <form
        onSubmit={(event) => {
          handleSubmit(event);
        }}
      >
        <div>
          <label>Title: </label>
          <input
            onChange={(event) => {
              setTitle(event.target.value);
            }}
            value={title}
            type="text"
          />
          {errors?.name && (
            <span style={{ color: "red" }}>{errors?.title?.message}</span>
          )}
        </div>

        <div>
          <label>Price: </label>
          <input
            onChange={(event) => {
              setPrice(event.target.value);
            }}
            value={price}
            type="number"
            min="0"
          />
          {errors?.price && (
            <span style={{ color: "red" }}>{errors?.price?.message}</span>
          )}
        </div>

        <div>
          <label>Description: </label>
          <input
            onChange={(event) => {
              setDescription(event.target.value);
            }}
            value={description}
            type="text"
          />
          {errors?.description && (
            <span style={{ color: "red" }}>{errors?.description?.message}</span>
          )}
        </div>
        <button>Submit</button>
        <button
          onClick={(event) => {
            handleDelete();
          }}>Delete</button>
        <Link to="/products">Cancel</Link>
      </form>
    </div>
  );
};

export default EditProduct;
