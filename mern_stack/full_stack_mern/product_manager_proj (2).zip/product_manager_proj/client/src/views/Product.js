import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, navigate } from "@reach/router";

const Product = (props) => {
  const [product, setProduct] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:8000/api/products/" + props.id)
      .then((res) => {
        // console.log(res);
        setProduct(res.data);
      })
      .catch((err) => {
        console.error(err);
      });
  }, [props.id]);

  function handleDelete() {
    axios
      .delete("http://localhost:8000/api/products/delete/" + props.id)
      .then((res) => {
        navigate('/products');
      })
      .catch((err) => {
        console.error(err);
      });
  }

  if (product === null) {
    return "Loading...";
  }

  return (
    <div className="" key={product._id}>
      <h3>{product.title}</h3>
      <p>Price: {product.price}</p>
      <p>Description: {product.description}</p>
      <Link to={`/products/${product._id}/edit`}>Edit</Link>
      <button onClick={(event) => {
          handleDelete(product._id);
      }}>
          Delete
      </button>
    </div>
  );
};

export default Product;