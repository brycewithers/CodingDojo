import React from 'react';

const Home = props => {
    return (
        <div>
            <h2>Welcome to my home page!</h2>
        </div>
    )
}

export default Home;